USE [DBS-Project];

CREATE TABLE Infantry (
    EquipmentID INT PRIMARY KEY,
    WeaponType VARCHAR(50),
    Caliber VARCHAR(20),
    ServiceYear INT,
    UnitAssignment VARCHAR(50)
);

CREATE TABLE Armored (
    EquipmentID INT PRIMARY KEY,
    VehicleType VARCHAR(50),
    ArmorThickness INT,
    MainGunCaliber VARCHAR(20),
    CrewSize INT
);

CREATE TABLE Artillery (
    EquipmentID INT PRIMARY KEY,
    Range INT,
    Caliber VARCHAR(20),
    MobilityType VARCHAR(30) CHECK (MobilityType IN ('Towed', 'Self-Propelled'))
);

CREATE TABLE SupportVehicles (
    EquipmentID INT PRIMARY KEY,
    VehicleType VARCHAR(50),
    Capacity INT,
    Purpose VARCHAR(100)
);

CREATE TABLE AttackHelicopters (
    EquipmentID INT PRIMARY KEY,
    MaxSpeed INT,
    Range INT,
    Armament VARCHAR(200),
    RotorDiameter DECIMAL(5,2)
);

CREATE TABLE FighterJets (
    EquipmentID INT PRIMARY KEY,
    MaxSpeed INT,
    CombatRadius INT,
    Armament VARCHAR(200),
    ThrustToWeightRatio DECIMAL(3,2)
);

CREATE TABLE AWACS (
    EquipmentID INT PRIMARY KEY,
    RadarRange INT,
    Endurance INT,
    CrewSize INT
);

CREATE TABLE CargoAircraft (
    EquipmentID INT PRIMARY KEY,
    PayloadCapacity INT,
    Range INT,
    CargoHoldDimensions VARCHAR(50)
);

CREATE TABLE AircraftCarriers (
    EquipmentID INT PRIMARY KEY,
    Displacement INT,
    AircraftCapacity INT,
    PropulsionType VARCHAR(50),
    CrewSize INT
);

CREATE TABLE Cruisers (
    EquipmentID INT PRIMARY KEY,
    Displacement INT,
    MissileSystems VARCHAR(200),
    TopSpeed INT
);

CREATE TABLE Frigates (
    EquipmentID INT PRIMARY KEY,
    Displacement INT,
    ASWCapabilities VARCHAR(200),
    Range INT
);


CREATE TABLE Corvettes (
    EquipmentID INT PRIMARY KEY,
    Displacement INT,
    PrimaryWeapon VARCHAR(100),
    CrewSize INT
);

INSERT INTO Infantry VALUES
(1, 'Assault Rifle', '5.56mm', 2021, 'Unit-3'),
(2, 'Sniper Rifle', '5.56mm', 2012, 'Unit-1'),
(3, 'Assault Rifle', '9mm', 2016, 'Unit-1'),
(4, 'SMG', '9mm', 2018, 'Unit-2'),
(5, 'LMG', '7.62mm', 2020, 'Unit-4'),
(6, 'Assault Rifle', '5.56mm', 2015, 'Unit-2'),
(7, 'Sniper Rifle', '7.62mm', 2019, 'Unit-5'),
(8, 'LMG', '7.62mm', 2017, 'Unit-3'),
(9, 'SMG', '9mm', 2014, 'Unit-4'),
(10, 'Assault Rifle', '5.56mm', 2022, 'Unit-5'),
(11, 'Sniper Rifle', '7.62mm', 2013, 'Unit-1'),
(12, 'LMG', '5.56mm', 2011, 'Unit-3'),
(13, 'Carbine', '5.56mm', 2023, 'Unit-6');


INSERT INTO Armored VALUES
(1, 'APC', 260, '30mm', 4),
(2, 'IFV', 149, '30mm', 3),
(3, 'Tank', 269, '120mm', 4),
(4, 'Tank', 220, '120mm', 4),
(5, 'APC', 175, '105mm', 3),
(6, 'IFV', 190, '30mm', 3),
(7, 'Tank', 300, '120mm', 5),
(8, 'APC', 210, '105mm', 4),
(9, 'IFV', 160, '30mm', 3),
(10, 'Tank', 275, '120mm', 5),
(11, 'APC', 180, '105mm', 4),
(12, 'IFV', 200, '30mm', 3),
(13, 'IFV', 210, '35mm', 4);


INSERT INTO Artillery VALUES
(1, 65, '105mm', 'Towed'),
(2, 70, '155mm', 'Self-Propelled'),
(3, 40, '105mm', 'Towed'),
(4, 60, '155mm', 'Self-Propelled'),
(5, 55, '105mm', 'Towed'),
(6, 80, '155mm', 'Self-Propelled'),
(7, 35, '105mm', 'Towed'),
(8, 75, '155mm', 'Self-Propelled'),
(9, 45, '105mm', 'Towed'),
(10, 66, '155mm', 'Self-Propelled'),
(11, 50, '105mm', 'Towed'),
(12, 68, '155mm', 'Self-Propelled'),
(13, 85, '155mm', 'Self-Propelled');


INSERT INTO SupportVehicles VALUES
(1, 'Truck', 10, 'Transport'),
(2, 'Jeep', 4, 'Logistics'),
(3, 'Ambulance', 2, 'Medical'),
(4, 'Truck', 12, 'Transport'),
(5, 'Jeep', 5, 'Logistics'),
(6, 'Ambulance', 3, 'Medical'),
(7, 'Truck', 15, 'Transport'),
(8, 'Jeep', 6, 'Logistics'),
(9, 'Ambulance', 2, 'Medical'),
(10, 'Truck', 8, 'Transport'),
(11, 'Jeep', 5, 'Logistics'),
(12, 'Ambulance', 3, 'Medical'),
(13, 'Jeep', 6, 'Communication');


INSERT INTO AttackHelicopters VALUES
(1, 270, 225, 'Rockets, Machine Gun', 13.87),
(2, 320, 420, 'Missiles, Gun', 14.50),
(3, 300, 350, 'Cannon, Rockets', 12.75),
(4, 260, 300, 'Missiles, Gun', 11.50),
(5, 310, 400, 'Rockets, Machine Gun', 13.10),
(6, 280, 320, 'Cannon, Rockets', 10.95),
(7, 330, 460, 'Missiles, Gun', 14.20),
(8, 295, 310, 'Rockets, Machine Gun', 11.30),
(9, 270, 290, 'Cannon, Rockets', 10.65),
(10, 310, 390, 'Missiles, Gun', 13.00),
(11, 285, 330, 'Cannon, Rockets', 12.10),
(12, 275, 340, 'Rockets, Machine Gun', 11.75),
(13, 300, 370, 'Missiles', 14.00);


INSERT INTO FighterJets VALUES
(1, 1264, 1380, 'Bombs, Missiles', 0.93),
(2, 1687, 785, 'Bombs, Missiles', 0.99),
(3, 1470, 1240, 'Bombs, Missiles', 1.00),
(4, 1590, 1100, 'Missiles, Gun', 1.10),
(5, 1310, 890, 'Missiles, Gun', 0.91),
(6, 1820, 1000, 'Bombs, Missiles', 1.15),
(7, 1455, 970, 'Missiles, Gun', 0.95),
(8, 1750, 1200, 'Bombs, Missiles', 1.02),
(9, 1230, 850, 'Missiles, Gun', 0.90),
(10, 1600, 1350, 'Bombs, Missiles', 1.20),
(11, 1505, 900, 'Missiles, Gun', 0.98),
(12, 1375, 1000, 'Bombs, Missiles', 1.05),
(13, 1400, 950, 'Missiles', 0.97);


INSERT INTO AWACS VALUES
(1, 450, 9, 15),
(2, 420, 10, 12),
(3, 400, 7, 14),
(4, 460, 11, 16),
(5, 430, 8, 11),
(6, 480, 10, 13),
(7, 410, 9, 10),
(8, 390, 6, 12),
(9, 470, 11, 17),
(10, 440, 9, 14),
(11, 360, 8, 13),
(12, 300, 7, 10),
(13, 410, 8, 11);

INSERT INTO CargoAircraft VALUES
(1, 25000, 3000, '35x15x12'),
(2, 28000, 3200, '40x20x10'),
(3, 30000, 3500, '30x18x14'),
(4, 27000, 2800, '38x12x11'),
(5, 26000, 3000, '36x14x13'),
(6, 32000, 4000, '33x16x10'),
(7, 29000, 3100, '34x15x12'),
(8, 24000, 2700, '32x10x11'),
(9, 35000, 4200, '39x18x15'),
(10, 31000, 3400, '37x17x12'),
(11, 22000, 2500, '29x13x10'),
(12, 33000, 3900, '36x16x13'),
(13, 27000, 3300, '33x15x12');



INSERT INTO AircraftCarriers VALUES
(1, 90000, 60, 'Nuclear', 4500),
(2, 85000, 55, 'Diesel', 4200),
(3, 80000, 50, 'Nuclear', 4000),
(4, 75000, 45, 'Diesel', 3800),
(5, 70000, 40, 'Nuclear', 3600),
(6, 65000, 35, 'Diesel', 3400),
(7, 60000, 30, 'Nuclear', 3200),
(8, 55000, 25, 'Diesel', 3000),
(9, 50000, 20, 'Nuclear', 2800),
(10, 95000, 65, 'Diesel', 4700),
(11, 100000, 70, 'Nuclear', 5000),
(12, 30000, 22, 'Diesel', 2500),
(13, 60000, 30, 'Diesel', 3000);


INSERT INTO Cruisers VALUES
(1, 9800, 'SM-2, Tomahawk', 32),
(2, 9600, 'SM-3, Harpoon', 30),
(3, 9400, 'Tomahawk, Sea Sparrow', 29),
(4, 9300, 'Harpoon, SM-1', 28),
(5, 9100, 'Sea Sparrow, SM-2', 27),
(6, 9000, 'SM-3, Tomahawk', 31),
(7, 8900, 'Harpoon, SM-2', 30),
(8, 8800, 'SM-1, Sea Sparrow', 26),
(9, 8700, 'Tomahawk, Harpoon', 32),
(10, 8600, 'SM-2, Sea Sparrow', 29),
(11, 8500, 'Harpoon, SM-3', 28),
(12, 8400, 'Tomahawk, SM-1', 27),
(13, 8200, 'Tomahawk, Harpoon', 28);

INSERT INTO Frigates VALUES
(1, 4500, 'Torpedoes, Sonar, Depth Charges', 4500),
(2, 4300, 'Sonar, Missiles, ASW Rockets', 4200),
(3, 4100, 'Torpedoes, Sonar', 4000),
(4, 4000, 'ASW Helicopter, Sonar', 3900),
(5, 3900, 'Depth Charges, Torpedoes', 3800),
(6, 3800, 'Missiles, Sonar', 3700),
(7, 3700, 'Torpedoes, ASW Rockets', 3600),
(8, 3600, 'Sonar, Helicopter', 3500),
(9, 3500, 'Depth Charges, Sonar', 3400),
(10, 3400, 'ASW Helicopter, Missiles', 3300),
(11, 3300, 'Torpedoes, Sonar', 3200),
(12, 3200, 'Missiles, Depth Charges', 3100),
(13, 3100, 'Sonar, Torpedoes', 3000);


INSERT INTO Corvettes VALUES
(1, 1800, '76mm Gun', 75),
(2, 1700, 'Missile Launcher', 70),
(3, 1600, 'Anti-Ship Missile', 68),
(4, 1500, 'Torpedo Tubes', 66),
(5, 1400, 'Anti-Air Gun', 65),
(6, 1300, 'Surface Missile', 63),
(7, 1200, '76mm Gun', 62),
(8, 1100, 'Missile Launcher', 60),
(9, 1000, 'Anti-Submarine Rockets', 58),
(10, 900, 'Torpedo Tubes', 55),
(11, 800, 'Surface Missile', 50),
(12, 700, '76mm Gun', 48),
(13, 650, 'Missile Launcher', 45);

--operations on infantory table
--SELECT
SELECT * FROM Infantry;

SELECT * FROM Infantry WHERE WeaponType = 'Sniper Rifle';
SELECT WeaponType, COUNT(*) FROM Infantry GROUP BY WeaponType;
-- UPDATE
UPDATE Infantry SET UnitAssignment = 'Unit-7' WHERE EquipmentID = 13;
-- DELETE
DELETE FROM Infantry WHERE EquipmentID = 13;

--operations on armored table
-- SELECT
SELECT * FROM Armored;

SELECT * FROM Armored WHERE ArmorThickness > 200;


SELECT VehicleType, AVG(ArmorThickness) AS AvgArmor FROM Armored GROUP BY VehicleType;
-- UPDATE
UPDATE Armored SET CrewSize = 5 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM Armored WHERE EquipmentID = 13;

--operations on Artillery table
-- SELECT
SELECT * FROM Artillery;

SELECT * FROM Artillery WHERE MobilityType = 'Towed';

SELECT MobilityType, COUNT(*) FROM Artillery GROUP BY MobilityType;

-- UPDATE
UPDATE Artillery SET Range = 90 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM Artillery WHERE EquipmentID = 13;

--operations on support vehicle table
-- SELECT
SELECT * FROM SupportVehicles;

SELECT * FROM SupportVehicles WHERE Purpose = 'Medical';

SELECT VehicleType, COUNT(*) FROM SupportVehicles GROUP BY VehicleType;

-- UPDATE
UPDATE SupportVehicles SET Capacity = 7 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM SupportVehicles WHERE EquipmentID = 13;

--operations on Attack helicopters table
-- SELECT
SELECT * FROM AttackHelicopters;
SELECT * FROM AttackHelicopters WHERE MaxSpeed > 300;

SELECT AVG(RotorDiameter) AS AvgRotor FROM AttackHelicopters;

-- UPDATE
UPDATE AttackHelicopters SET Range = 400 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM AttackHelicopters WHERE EquipmentID = 13;

--operations on Fighter jets table
-- SELECT
SELECT * FROM FighterJets;
SELECT * FROM FighterJets WHERE ThrustToWeightRatio > 1.0;


SELECT MAX(CombatRadius) FROM FighterJets;

-- UPDATE
UPDATE FighterJets SET Armament = 'Missiles, Bombs' WHERE EquipmentID = 13;
-- DELETE
DELETE FROM FighterJets WHERE EquipmentID = 13;

--operations on AWACS table
-- SELECT
SELECT * FROM AWACS;

SELECT * FROM AWACS WHERE RadarRange > 400;

SELECT CrewSize, COUNT(*) FROM AWACS GROUP BY CrewSize;

-- UPDATE
UPDATE AWACS SET Endurance = 12 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM AWACS WHERE EquipmentID = 13;

--operations on Cargo aircraft table
-- SELECT
SELECT * FROM CargoAircraft;

SELECT * FROM CargoAircraft WHERE Range >= 3000;

SELECT AVG(PayloadCapacity) FROM CargoAircraft;

-- UPDATE
UPDATE CargoAircraft SET PayloadCapacity = 28000 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM CargoAircraft WHERE EquipmentID = 13;

--operations on Aircraft Carriers table
-- SELECT
SELECT * FROM AircraftCarriers;
SELECT * FROM AircraftCarriers WHERE PropulsionType = 'Nuclear';

SELECT AVG(AircraftCapacity) FROM AircraftCarriers;

-- UPDATE
UPDATE AircraftCarriers SET Displacement = 65000 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM AircraftCarriers WHERE EquipmentID = 13;

--operations on Cruisers table
-- SELECT
SELECT * FROM Cruisers;
SELECT * FROM Cruisers WHERE TopSpeed > 30;

SELECT Displacement, COUNT(*) FROM Cruisers GROUP BY Displacement;

-- UPDATE
UPDATE Cruisers SET TopSpeed = 29 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM Cruisers WHERE EquipmentID = 13;

--operations on Frigates table
-- SELECT
SELECT * FROM Frigates;
SELECT * FROM Frigates WHERE Range > 4000;


SELECT AVG(Displacement) FROM Frigates;

-- UPDATE
UPDATE Frigates SET ASWCapabilities = 'Torpedoes, Sonar, Depth Charges' WHERE EquipmentID = 13;
-- DELETE
DELETE FROM Frigates WHERE EquipmentID = 13;

--operations on Corvettes table
-- SELECT
SELECT * FROM Corvettes;
SELECT * FROM Corvettes WHERE PrimaryWeapon = '76mm Gun';

SELECT MAX(Displacement) FROM Corvettes;

-- UPDATE
UPDATE Corvettes SET CrewSize = 50 WHERE EquipmentID = 13;
-- DELETE
DELETE FROM Corvettes WHERE EquipmentID = 13;



-- Trigger to log deletion from FighterJets
CREATE TABLE FighterJets_Log (
    EquipmentID INT,
    DeletedOn DATETIME
);

go;

CREATE TRIGGER trg_DeleteFighterJet
ON FighterJets
AFTER DELETE
AS
BEGIN
    INSERT INTO FighterJets_Log (EquipmentID, DeletedOn)
    SELECT EquipmentID, GETDATE() FROM deleted;
END;
go;



CREATE VIEW ArmyEquipment AS
SELECT 'Infantry' AS Type, EquipmentID, WeaponType AS Detail1, Caliber AS Detail2
FROM Infantry
UNION ALL
SELECT 'Armored', EquipmentID, VehicleType, MainGunCaliber
FROM Armored
UNION ALL
SELECT 'Artillery', EquipmentID, MobilityType, Caliber
FROM Artillery
UNION ALL
SELECT 'SupportVehicle', EquipmentID, VehicleType, Purpose
FROM SupportVehicles;
go;

select * from ArmyEquipment;


SELECT A.EquipmentID, A.VehicleType, A.MainGunCaliber, A.CrewSize, S.VehicleType AS SupportVehicle
FROM Armored A
INNER JOIN SupportVehicles S
ON A.EquipmentID = S.EquipmentID;

SELECT I.EquipmentID, I.WeaponType, A.Range, A.MobilityType
FROM Infantry I
LEFT JOIN Artillery A
ON I.EquipmentID = A.EquipmentID;

SELECT A.EquipmentID, A.Range, A.MobilityType, I.WeaponType
FROM Infantry I
RIGHT JOIN Artillery A
ON I.EquipmentID = A.EquipmentID;

SELECT 
    F.EquipmentID AS FighterJetID,
    F.MaxSpeed AS Fighter_MaxSpeed,
    F.CombatRadius AS Fighter_CombatRadius,
    F.Armament AS Fighter_Armament,
    F.ThrustToWeightRatio AS Fighter_TWR,

    H.EquipmentID AS HelicopterID,
    H.MaxSpeed AS Heli_MaxSpeed,
    H.Range AS Heli_Range,
    H.Armament AS Heli_Armament,
    H.RotorDiameter AS Heli_RotorDiameter

FROM FighterJets F
FULL OUTER JOIN AttackHelicopters H
    ON F.EquipmentID = H.EquipmentID;

