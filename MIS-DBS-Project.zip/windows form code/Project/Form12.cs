﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form12 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;
        public Form12()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Frigates (EquipmentID, Displacement, ASWCapabilities, Range) " +
                               "VALUES (@EquipmentID, @Displacement, @ASWCapabilities, @Range)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));
                    cmd.Parameters.AddWithValue("@Displacement", int.Parse(txtDisplacement.Text));
                    cmd.Parameters.AddWithValue("@ASWCapabilities", txtASWCapabilities.Text);
                    cmd.Parameters.AddWithValue("@Range", int.Parse(txtRange.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Frigate record added successfully!");
                    ClearFields();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Frigates WHERE EquipmentID = @EquipmentID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Frigate record deleted successfully!");
                    ClearFields();
                }
            }
        }

        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtDisplacement.Clear();
            txtASWCapabilities.Clear();
            txtRange.Clear();
        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Frigates";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView12.DataSource = dt;
            }
        }
        private void Form12_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
