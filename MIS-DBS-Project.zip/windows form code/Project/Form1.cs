﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 infantryForm = new Form2();
            infantryForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 armoredForm = new Form3();
            armoredForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 artilleryForm = new Form4();
            artilleryForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 supportvehicle = new Form5();
            supportvehicle.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form6 attackhelicopters = new Form6();
            attackhelicopters.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form7 fighterjets = new Form7();
            fighterjets.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form8 AWACS = new Form8();
            AWACS.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form9 cargoaircraft = new Form9();
            cargoaircraft.Show();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            Form10 aircraftcarriers = new Form10();
            aircraftcarriers.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form11 cruisers = new Form11();
            cruisers.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form12 frigates = new Form12();
            frigates.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form13 corvettes = new Form13();
            corvettes.Show();
        }
    }
}
