﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form9 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO CargoAircraft (EquipmentID, PayloadCapacity, Range, CargoHoldDimensions) " +
                               "VALUES (@EquipmentID, @PayloadCapacity, @Range, @CargoHoldDimensions)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));
                    cmd.Parameters.AddWithValue("@PayloadCapacity", int.Parse(txtPayloadCapacity.Text));
                    cmd.Parameters.AddWithValue("@Range", int.Parse(txtRange.Text));
                    cmd.Parameters.AddWithValue("@CargoHoldDimensions", txtCargoHoldDimensions.Text);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record added successfully!");
                    ClearFields();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM CargoAircraft  WHERE EquipmentID = @EquipmentID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record deleted successfully!");
                    ClearFields();
                }
            }
        }

        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtPayloadCapacity.Clear();
            txtRange.Clear();
            txtCargoHoldDimensions.Clear();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM CargoAircraft";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView9.DataSource = dt;
            }
        }
        private void Form9_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
