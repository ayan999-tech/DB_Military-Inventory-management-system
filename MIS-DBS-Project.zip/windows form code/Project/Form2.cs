﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace Project
{
    public partial class Form2 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;

        public Form2()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM Infantry";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView2.DataSource = dt;
                }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData();
        }
     

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Infantry (EquipmentID, WeaponType, Caliber, ServiceYear, UnitAssignment) " +
                               "VALUES (@EquipmentID, @WeaponType, @Caliber, @ServiceYear, @UnitAssignment)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@EquipmentID", txtEquipmentID.Text);
                cmd.Parameters.AddWithValue("@WeaponType", txtWeaponType.Text);
                cmd.Parameters.AddWithValue("@Caliber", txtCaliber.Text);
                cmd.Parameters.AddWithValue("@ServiceYear", txtServiceYear.Text);
                cmd.Parameters.AddWithValue("@UnitAssignment", txtUnitAssignment.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Record added successfully!");
                ClearFields();
             }

         }
        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Infantry WHERE EquipmentID = @EquipmentID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EquipmentID", txtEquipmentID.Text);

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                conn.Close();

                if (rowsAffected > 0)
                    MessageBox.Show("Record deleted successfully!");
                else
                    MessageBox.Show("Record not found!");

                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtWeaponType.Clear();
            txtCaliber.Clear();
            txtServiceYear.Clear();
            txtUnitAssignment.Clear();
        }
    }
}
