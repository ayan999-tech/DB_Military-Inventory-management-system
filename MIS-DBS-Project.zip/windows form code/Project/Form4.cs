﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form4 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Artillery (EquipmentID, Range, Caliber, MobilityType) VALUES (@EquipmentID, @Range, @Caliber, @MobilityType)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", txtEquipmentID.Text);
                    cmd.Parameters.AddWithValue("@Range", txtRange.Text);
                    cmd.Parameters.AddWithValue("@Caliber", txtCaliber.Text);
                    cmd.Parameters.AddWithValue("@MobilityType", txtMobilityType.Text);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Artillery added successfully.");
                    ClearFields();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Artillery WHERE EquipmentID = @EquipmentID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", txtEquipmentID.Text);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Artillery deleted successfully.");
                    ClearFields();
                }
            }
        }
        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtRange.Clear();
            txtCaliber.Clear();
            txtMobilityType.SelectedIndex = -1;  

        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Artillery";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView4.DataSource = dt;
            }
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
