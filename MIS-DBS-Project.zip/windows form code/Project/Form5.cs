﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form5 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO SupportVehicles (EquipmentID, VehicleType, Capacity, Purpose) VALUES (@EquipmentID, @VehicleType, @Capacity, @Purpose)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));
                    cmd.Parameters.AddWithValue("@VehicleType", txtVehicleType.Text);
                    cmd.Parameters.AddWithValue("@Capacity", int.Parse(txtCapacity.Text));
                    cmd.Parameters.AddWithValue("@Purpose", txtPurpose.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Record added successfully!");
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM SupportVehicles WHERE EquipmentID = @EquipmentID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Record deleted successfully!");
                    else
                        MessageBox.Show("Record not found.");

                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtVehicleType.Clear();
            txtCapacity.Clear();
            txtPurpose.Clear();
        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM SupportVehicles";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView5.DataSource = dt;
            }
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
