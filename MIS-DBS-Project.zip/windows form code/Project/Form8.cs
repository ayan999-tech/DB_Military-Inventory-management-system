﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form8 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO AWACS (EquipmentID, RadarRange, Endurance, CrewSize) " +
                               "VALUES (@EquipmentID, @RadarRange, @Endurance, @CrewSize)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));
                    cmd.Parameters.AddWithValue("@RadarRange", int.Parse(txtRadarRange.Text));
                    cmd.Parameters.AddWithValue("@Endurance", int.Parse(txtEndurance.Text));
                    cmd.Parameters.AddWithValue("@CrewSize", int.Parse(txtCrewSize.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record added successfully!");
                    ClearFields();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM AWACS WHERE EquipmentID = @EquipmentID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record deleted successfully!");
                    ClearFields();
                }
            }
        }
        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtRadarRange.Clear();
            txtEndurance.Clear();
            txtCrewSize.Clear();
        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM AWACS";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView8.DataSource = dt;
            }
        }
        private void Form8_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
