﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form7 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;
        public Form7()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO FighterJets (EquipmentID, MaxSpeed, CombatRadius, Armament, ThrustToWeightRatio) " +
                               "VALUES (@EquipmentID, @MaxSpeed, @CombatRadius, @Armament, @ThrustToWeightRatio)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));
                    cmd.Parameters.AddWithValue("@MaxSpeed", int.Parse(txtMaxSpeed.Text));
                    cmd.Parameters.AddWithValue("@CombatRadius", int.Parse(txtCombatRadius.Text));
                    cmd.Parameters.AddWithValue("@Armament", txtArmament.Text);
                    cmd.Parameters.AddWithValue("@ThrustToWeightRatio", decimal.Parse(txtThrustToWeightRatio.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record added successfully!");
                    ClearFields();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM FighterJets WHERE EquipmentID = @EquipmentID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EquipmentID", int.Parse(txtEquipmentID.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record deleted successfully!");
                    ClearFields();
                }
            }
        }

        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtMaxSpeed.Clear();
            txtCombatRadius.Clear();
            txtArmament.Clear();
            txtThrustToWeightRatio.Clear();
        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM FighterJets";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView7.DataSource = dt;
            }
        }
        private void Form7_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
