﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project
{
    public partial class Form3 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["MilitaryDB"].ConnectionString;

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Armored (EquipmentID, VehicleType, ArmorThickness, MainGunCaliber, CrewSize) " +
                               "VALUES (@EquipmentID, @VehicleType, @ArmorThickness, @MainGunCaliber, @CrewSize)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EquipmentID", txtEquipmentID.Text);
                cmd.Parameters.AddWithValue("@VehicleType", txtVehicleType.Text);
                cmd.Parameters.AddWithValue("@ArmorThickness", txtArmorThickness.Text);
                cmd.Parameters.AddWithValue("@MainGunCaliber", txtMainGunCaliber.Text);
                cmd.Parameters.AddWithValue("@CrewSize", txtCrewSize.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Record added successfully!");
                ClearFields();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Armored WHERE EquipmentID = @EquipmentID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EquipmentID", txtEquipmentID.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Record deleted successfully!");
                ClearFields();
            }
        }
        private void ClearFields()
        {
            txtEquipmentID.Clear();
            txtEquipmentID.Clear();
            txtArmorThickness.Clear();
            txtMainGunCaliber.Clear();
            txtCrewSize.Clear();
        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Armored";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView3.DataSource = dt;
            }
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            LoadData();
        }

    }
}
